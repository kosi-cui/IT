This is a placeholder ticket file.
Actual ticket files are not stored in the repo for security reasons.